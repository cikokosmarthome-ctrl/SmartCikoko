package com.example.smartcikoko

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
