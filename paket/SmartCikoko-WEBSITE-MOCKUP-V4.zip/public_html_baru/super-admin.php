<?php
declare(strict_types=1);
header('Cache-Control: private,no-store,max-age=0');
header('X-Robots-Tag: noindex,nofollow,noarchive');
try{
    require dirname(__DIR__).'/portal_private/bootstrap.php';
    require_super_admin();
}catch(Throwable $e){
    http_response_code(503);exit('Super Administrator belum dapat dibuka.');
}
header('Location: /super-admin-satu.php',true,303);
exit;
